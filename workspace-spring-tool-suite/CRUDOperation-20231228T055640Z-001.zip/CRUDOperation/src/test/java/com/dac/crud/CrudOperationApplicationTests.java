package com.dac.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
