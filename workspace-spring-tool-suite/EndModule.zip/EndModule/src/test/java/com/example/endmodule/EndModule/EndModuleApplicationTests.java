package com.example.endmodule.EndModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
