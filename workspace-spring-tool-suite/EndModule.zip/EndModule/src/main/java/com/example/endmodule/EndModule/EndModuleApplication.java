package com.example.endmodule.EndModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndModuleApplication.class, args);
	}

}
