package com.dac.emtt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndModuleTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndModuleTestApplication.class, args);
	}

}
